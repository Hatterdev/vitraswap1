self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "71bd7707034846fba47b",
    "url": "/css/app.e7fb2dfb.css"
  },
  {
    "revision": "72753ea61bc2386e7d9b",
    "url": "/css/chunk-vendors.c5c955ed.css"
  },
  {
    "revision": "7148a93aae655faff9daffa99e28bb3f",
    "url": "/favicon/android-chrome-192x192.png"
  },
  {
    "revision": "3f978d3d9a1e72922465aa083c8e42d7",
    "url": "/favicon/android-chrome-512x512.png"
  },
  {
    "revision": "ee57fabc52d4f4827f99987518ac2404",
    "url": "/favicon/apple-touch-icon.png"
  },
  {
    "revision": "b6396ae05adecaa99a4be08fa23080ee",
    "url": "/favicon/browserconfig.xml"
  },
  {
    "revision": "b5d45eb659879c04048a1238b888d08a",
    "url": "/favicon/favicon-16x16.png"
  },
  {
    "revision": "c0ef3f775af2d4ee322bcb94a59012fb",
    "url": "/favicon/favicon-32x32.png"
  },
  {
    "revision": "e4ad55befd4f4068a708a4a64ef41114",
    "url": "/favicon/safari-pinned-tab.svg"
  },
  {
    "revision": "053100cb84a50d2ae7f5492f7dd7f25e",
    "url": "/favicon/site.webmanifest"
  },
  {
    "revision": "52c460abbca8ea635e3315a0b689ca43",
    "url": "/fonts/AndradePro-Regular.52c460ab.ttf"
  },
  {
    "revision": "e7a8ca80bbe41862541452bc6c27212a",
    "url": "/img/arrow-down.svg"
  },
  {
    "revision": "f7a4c33a16de14cabd6eec06ebd237f9",
    "url": "/img/bg3.f7a4c33a.png"
  },
  {
    "revision": "f9dc9a2b6c3bf4522221e15db3d2c52b",
    "url": "/img/cht.png"
  },
  {
    "revision": "500ffa2d7ef56c83c9a76f6ef5e89d08",
    "url": "/img/fantom-logo.png"
  },
  {
    "revision": "0425fd614bf693602f58687e6b2fd35a",
    "url": "/img/searchIcon.svg"
  },
  {
    "revision": "44625a138296d6659b94e08a6f7e8fdb",
    "url": "/img/ult.jpg"
  },
  {
    "revision": "a11cba1c0299de5f297bb1f8ad6c7439",
    "url": "/img/uoge.png"
  },
  {
    "revision": "e301ae0abe571ad823fb7681ee5b6a8d",
    "url": "/img/vfi.jpg"
  },
  {
    "revision": "10957883352669f842fb14ae4119741d",
    "url": "/img/vinuchain-icon.svg"
  },
  {
    "revision": "90899f63993b94eb2998cff6cbe1f4c1",
    "url": "/img/vitrachain-icon.png"
  },
  {
    "revision": "1587ab6c552461378f2017b632954073",
    "url": "/img/wvc.png"
  },
  {
    "revision": "3c979b991384f8de86a03a910f4ee8e7",
    "url": "/index.html"
  },
  {
    "revision": "71bd7707034846fba47b",
    "url": "/js/app.6846a2d7.js"
  },
  {
    "revision": "2df9f78f39865b867274",
    "url": "/js/chunk-7c62a161.32f86d0c.js"
  },
  {
    "revision": "a281e527827badd237c7",
    "url": "/js/chunk-c9d86d40.cf02f453.js"
  },
  {
    "revision": "72753ea61bc2386e7d9b",
    "url": "/js/chunk-vendors.c97367e2.js"
  },
  {
    "revision": "2f92bec279bd73199005e85dc5c12278",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "19dd92ddd5f8f106990c6bd7d3ba2c4a",
    "url": "/switch-chain-vitra.png"
  },
  {
    "revision": "eeb7240aa758625f89a95489f50acbbc",
    "url": "/switch-chain.png"
  },
  {
    "revision": "ba29d5c9cdcfd80fe70822f5e5392fd5",
    "url": "/vitra-logo-dark.svg"
  },
  {
    "revision": "d4473caeee800131712c3a59f4a4c851",
    "url": "/vitra-logo-dark_old.svg"
  }
]);